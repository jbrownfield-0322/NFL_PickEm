package com.nflpickem.pickem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PickemApplicationTests {

	@Test
	void contextLoads() {
	}

}
