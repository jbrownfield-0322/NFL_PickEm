package com.nflpickem.pickem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PickemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PickemApplication.class, args);
	}

}
